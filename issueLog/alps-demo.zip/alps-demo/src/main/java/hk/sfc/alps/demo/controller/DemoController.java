package hk.sfc.alps.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import hk.sfc.alps.demo.model.SecurityObject;
import hk.sfc.alps.demo.service.SecurityObjectService;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/")
@Slf4j
public class DemoController {
	@Autowired
	SecurityObjectService secObjService;

	@PostMapping("/security-object")
	public void insertSecurityObject(@RequestBody SecurityObject secObj) {
		secObjService.insertSecurityObject(secObj);
	}
	@GetMapping("/security-object/{objectCode}")
	public SecurityObject getSecurityObject(@PathVariable("objectCode") String objectCode) {
		return secObjService.getSecurityObject(objectCode);
	}
	@PutMapping("/security-object")
	public void updateSecurityObject(@RequestBody SecurityObject secObj) {
		secObjService.updateSecurityObject(secObj);
	}
	@DeleteMapping("/security-object/{objectCode}")
	public void deleteSecurityObject(@PathVariable("objectCode") String objectCode) {
		secObjService.deleteSecurityObject(objectCode);
	}
	@GetMapping("/security-objects")
	public List<SecurityObject> listAllSecurityObject(){
		return secObjService.listAllSecurityObject();
	}
	

}
