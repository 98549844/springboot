package hk.sfc.alps.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import hk.sfc.alps.demo.model.SecurityObject;
import hk.sfc.alps.demo.model.mapper.SecurityObjectMapper;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SecurityObjectDao {

	@Autowired
	SecurityObjectMapper securityObjectMapper;

	public void insertSecurityObject(SecurityObject secObj) {
		securityObjectMapper.insertSecurityObject(secObj);
	}

	public SecurityObject getSecurityObject(String objectCode) {
		return securityObjectMapper.getSecurityObject(objectCode);
	}

	public void updateSecurityObject(SecurityObject secObj) {
		securityObjectMapper.updateSecurityObject(secObj);
	}

	public void deleteSecurityObject(String objectCode) {
		securityObjectMapper.deleteSecurityObject(objectCode);
	}

	public List<SecurityObject> listAllSecurityObject() {
		return securityObjectMapper.listAllSecurityObject();
	}

}
