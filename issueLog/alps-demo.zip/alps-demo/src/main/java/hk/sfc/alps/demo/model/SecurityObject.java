package hk.sfc.alps.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class SecurityObject {

	private String objectCode;
	private String objectDescription;
	private String authProvider;

	

}
