package hk.sfc.alps.demo.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import hk.sfc.alps.demo.model.SecurityObject;

@Mapper
public interface SecurityObjectMapper {

	public void insertSecurityObject(SecurityObject secObj);

	public SecurityObject getSecurityObject(String objectCode);

	public void updateSecurityObject(SecurityObject secObj);

	public void deleteSecurityObject(String objectCode);

	public List<SecurityObject> listAllSecurityObject();

}
