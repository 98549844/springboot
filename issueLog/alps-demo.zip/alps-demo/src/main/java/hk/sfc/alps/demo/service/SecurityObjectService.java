package hk.sfc.alps.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hk.sfc.alps.demo.dao.SecurityObjectDao;
import hk.sfc.alps.demo.model.SecurityObject;
import lombok.extern.slf4j.Slf4j;

@Service
public class SecurityObjectService {

	@Autowired
	SecurityObjectDao secObjDao;

	public void insertSecurityObject(SecurityObject secObj) {
		secObjDao.insertSecurityObject(secObj);
	}

	public SecurityObject getSecurityObject(String objectCode) {
		return secObjDao.getSecurityObject(objectCode);
	}

	public void updateSecurityObject(SecurityObject secObj) {
		secObjDao.updateSecurityObject(secObj);
	}

	public void deleteSecurityObject(String objectCode) {
		secObjDao.deleteSecurityObject(objectCode);
	}

	public List<SecurityObject> listAllSecurityObject() {
		return secObjDao.listAllSecurityObject();
	}
}
