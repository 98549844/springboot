package hk.sfc.alps.demo;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.test.context.junit4.SpringRunner;

import hk.sfc.alps.demo.model.SecurityObject;
import hk.sfc.alps.demo.model.mapper.SecurityObjectMapper;

@RunWith(SpringRunner.class)
@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class DemoApplicationTests {

	@Autowired
	private SecurityObjectMapper securityObjectMapper;

	private final String OBJECT_CODE = "Test";
	private final String OBJECT_DESCRIPTION = "TestDescription";
	private final String OBJECT_DESCRIPTION2 = "TestDescription2";
	private final String AUTH_PROVIDER = "TestAuthProvider";

	@Test
	public void testMapper() {
		SecurityObject secObj = new SecurityObject();
		secObj.setObjectCode(OBJECT_CODE);
		secObj.setObjectDescription(OBJECT_DESCRIPTION);
		secObj.setAuthProvider(AUTH_PROVIDER);
		securityObjectMapper.insertSecurityObject(secObj);
		
		SecurityObject secObj1 = securityObjectMapper.getSecurityObject(OBJECT_CODE);
		Assert.assertTrue(OBJECT_DESCRIPTION.equals(secObj1.getObjectDescription()));
        
		secObj1.setObjectDescription(OBJECT_DESCRIPTION2);
		securityObjectMapper.updateSecurityObject(secObj1);
		SecurityObject secObj2 = securityObjectMapper.getSecurityObject(OBJECT_CODE);
		Assert.assertTrue(OBJECT_DESCRIPTION2.equals(secObj2.getObjectDescription()));
        
		securityObjectMapper.deleteSecurityObject(OBJECT_CODE);
		SecurityObject secObj3 = securityObjectMapper.getSecurityObject(OBJECT_CODE);
		Assert.assertNull(secObj3);
        
    }
	
	
	

}
